﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InitMvc.Model
{
    public class SQLEmployeeData
    {
        private ApplicationContext _context { get; set; }

        public SQLEmployeeData(ApplicationContext context)
        {
            _context = context;
        }
        public void Add(Employee emp)
        {
            _context.Employees.Add(emp);
            _context.SaveChanges();
        }
        public Employee Get(int ID)
        {
            return _context.Employees.FirstOrDefault(e => e.ID == ID);
        }
        public IEnumerable<Employee> GetAll()
        {
            return _context.Employees.ToList();
        }
    }
}
