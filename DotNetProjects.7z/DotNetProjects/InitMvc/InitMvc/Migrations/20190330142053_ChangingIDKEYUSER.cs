﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace InitMvc.Migrations
{
    public partial class ChangingIDKEYUSER : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
