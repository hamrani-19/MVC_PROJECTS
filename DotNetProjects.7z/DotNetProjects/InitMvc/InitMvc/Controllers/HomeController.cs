﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InitMvc.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace InitMvc.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        [AllowAnonymous]
        public IActionResult Index()
        {
            var model = new HomePageViewModel();

            using (var context = new ApplicationContext())
            {
                SQLEmployeeData sqlData = new SQLEmployeeData(context);
                model.Employees = sqlData.GetAll();
            }
            return View(model);
        }

        public IActionResult Details(int id)
        {
            var context = new ApplicationContext();
            SQLEmployeeData sqlData = new SQLEmployeeData(context);
            var model = sqlData.Get(id);

            if (model == null)
            {
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var context = new ApplicationContext();
            SQLEmployeeData sqlData = new SQLEmployeeData(context);
            var model = sqlData.Get(id);

            if (model == null)
            {
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        [HttpPost]
        public IActionResult Edit(int id, EmployeeEditViewModel input)
        {
            var context = new ApplicationContext();
            SQLEmployeeData sqlData = new SQLEmployeeData(context);
            var employee = sqlData.Get(id);

            if (employee != null && ModelState.IsValid)
            {
                employee.Name = input.Name;
                context.SaveChanges();
                return RedirectToAction(nameof(Details), new { id = employee.ID });
            }
            return View(employee);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(EmployeeEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                var employee = new Employee();
                employee.Name = model.Name;
                var context = new ApplicationContext();

                SQLEmployeeData sqlData = new SQLEmployeeData(context);
                sqlData.Add(employee);
                return RedirectToAction(nameof(Details), new { id = employee.ID });
            }
            return View();
        }
    }
}  