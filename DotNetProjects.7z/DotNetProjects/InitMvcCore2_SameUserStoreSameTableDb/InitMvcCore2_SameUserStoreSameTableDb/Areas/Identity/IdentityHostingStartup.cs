﻿using System;
using InitMvcCore2_SameUserStoreSameTableDb.Data;
using InitMvcCore2_SameUserStoreSameTableDb.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(InitMvcCore2_SameUserStoreSameTableDb.Areas.Identity.IdentityHostingStartup))]
namespace InitMvcCore2_SameUserStoreSameTableDb.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
            });
        }
    }
}