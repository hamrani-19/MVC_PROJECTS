﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InitMvcCore2_SameUserStoreSameTableDb.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string Das { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string YearsExperience { get; set; }


        public ApplicationUser() : base()
        {

        }
    }
}
