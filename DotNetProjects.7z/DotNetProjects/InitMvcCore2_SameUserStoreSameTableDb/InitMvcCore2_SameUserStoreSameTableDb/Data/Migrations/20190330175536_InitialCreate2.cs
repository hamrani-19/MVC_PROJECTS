﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace InitMvcCore2_SameUserStoreSameTableDb.Data.Migrations
{
    public partial class InitialCreate2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
