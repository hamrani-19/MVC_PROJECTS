﻿using System;
using System.Collections.Generic;
using System.Text;
using InitMvcCore2_SameUserStoreSameTableDb.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace InitMvcCore2_SameUserStoreSameTableDb.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<IdentityUser>()
                .ToTable("User")
                .Property(x => x.Id).HasColumnName("UserId");

            builder.Entity<IdentityUserRole<string>>()
                .ToTable("UserRole");

            builder.Entity<IdentityUserClaim<string>>()
                .ToTable("UserClaim")
                .Property(x => x.Id).HasColumnName("UserClaimId");

            builder.Entity<IdentityUserToken<string>>()
                .ToTable("UserToken");

            builder.Entity<IdentityUserLogin<string>>()
                .ToTable("UserLogin");

            builder.Entity<IdentityRole>()
                .ToTable("Role")
                .Property(x => x.Id).HasColumnName("RoleId");

            builder.Entity<IdentityRoleClaim<string>>()
                .ToTable("RoleClaim")
                .Property(x => x.Id).HasColumnName("RoleClaimId");
        }
    }
}
