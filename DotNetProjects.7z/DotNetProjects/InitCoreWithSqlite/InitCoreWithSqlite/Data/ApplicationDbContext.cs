﻿using System;
using System.Collections.Generic;
using System.Text;
using InitCoreWithSqlite.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace InitCoreWithSqlite.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, string>
    {
        public ApplicationDbContext()
            : base()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<ApplicationUser>()
                .ToTable("User")
                .Property(x => x.Id).HasColumnName("UserId");

            builder.Entity<ApplicationRole>()
                .ToTable("Role")
                .Property(x => x.Id).HasColumnName("RoleId");
            ;
            builder.Entity<IdentityUserRole<string>>()
                .ToTable("UserRole");

        }

    }
}
