﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InitCoreWithSqlite.Models
{
    public class ApplicationUser : IdentityUser<string>
    {
        public string Das { get; set; }

        public ApplicationUser() : base()
        {

        }
    }
}
